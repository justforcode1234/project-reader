<script setup>
import Carousel from '../components/carousel.vue';

</script>

<template>
<div>
    <div class="w-[80%] mx-auto ">
        <h1>NEW ON READER</h1>
        <Carousel />
    </div>
</div>
</template>

<style scoped>
</style>