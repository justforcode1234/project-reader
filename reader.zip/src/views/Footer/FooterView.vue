<script setup>
</script>

<template>
    <div class="flex flex-col gap-3 items-center justify-center bg-black color-white p-20 ">
        <ul class="flex gap-5">
            <li>Home</li>
            <li>Privacy Policy</li>
            <li>Terms of Service</li>
            <li>Contact</li>
            <li>Discord</li>
        </ul>
        <p class="t-13 color-gray">© 2019-2023 Toonily.</p>
    </div>
</template>

<style scoped>
</style>