<script setup>
</script>

<template>
    <div class="flex justify-between items-center p-5 bg-gray t-13 cursor-pointer rounded">
        <p>Chapter 13</p>
        <p>Sep 11,25</p>
    </div>
</template>

<style scoped></style>