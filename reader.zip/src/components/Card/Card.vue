<script setup>
import CardChapter from './CardChapter.vue';
const props=defineProps({
    chapter:Object
})
</script>

<template>
    <div class="w-full max-w-[160px] flex flex-col gap-2 rounded w-full">
        <img class="w-100% rounded" src="@/assets/images/cover/cover1.jpg" alt="">
        <h4 class="truncate">{{props.chapter.title}}</h4>
        <div class="flex items-center justify-between border border-gray border-solid rounded p-3 t-15">
            <div class="flex gap-1 items-center justify-center">
                <img class="size-15" src="@/assets/images/common/star.svg" alt="">
                <p class="lh-15">{{ props.chapter.rating }}</p>
            </div>
            <div class="flex gap-1 items-center justify-center">
                <img class="size-15" src="@/assets/images/common/view.svg" alt="">
                <p class="lh-15">{{props.chapter.views}}</p>
            </div>
        </div>
        <div class="flex flex-col gap-1">
            <CardChapter />
            <CardChapter />
        </div>

    </div>
</template>

<style scoped></style>