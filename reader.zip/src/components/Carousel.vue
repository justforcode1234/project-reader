<script setup>
import Card from './Card/Card.vue';
import chapters from '@/chapters.json'


</script>

<template>
    <!-- <div class="grid items-center justify-items-center lg:grid-cols-6 md:grid-cols-4 grid-cols-2 gap-4 bg-yellow "> -->
        <div class="flex flex-wrap bg-yellow">
            <Card v-for="chapter in chapters.cards" :key="chapter.id" :chapter="chapter"/>
        </div>
        
</template>

<style scoped></style>