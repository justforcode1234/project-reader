<template>
    auth
    <RouterView/>
</template>
<script></script>